# Automatically Attach Issues to Wiki Pages

This plan outlines the implementation of a new feature for the `redmine_wysiwyg_editor` plugin: automatically displaying a list of issues that mention the current wiki page at the bottom of that page.

## Proposed Changes

We will introduce a Redmine **View Hook** that injects a new section at the bottom of every Wiki page (using the `view_wiki_show_bottom` hook). This section will query the Redmine database to find any issues that link to the current wiki page, and display them in a list.

### `lib/redmine_wysiwyg_editor/hooks.rb`
#### [NEW] [hooks.rb](file:///c:/Users/chris/Downloads/redmine_wysiwyg_editor-0.34.0/lib/redmine_wysiwyg_editor/hooks.rb)
- Create a new ViewListener class that hooks into `view_wiki_show_bottom`.
- Add logic to extract the current wiki page title.
- Query the `Issue` and `Journal` (issue notes) tables for any text that matches the `[[Page Title]]` or `[[Page_Title]]` markdown syntax.

### `app/views/redmine_wysiwyg_editor/_wiki_issues.html.erb`
#### [NEW] [_wiki_issues.html.erb](file:///c:/Users/chris/Downloads/redmine_wysiwyg_editor-0.34.0/app/views/redmine_wysiwyg_editor/_wiki_issues.html.erb)
- Create a new view template to render the list of issues cleanly.
- It will include a "Related Issues" header.
- It will loop through the matched issues and render them as clickable links (e.g. `#123: Issue Subject`), along with their status, similar to Redmine's native issue lists.

### `init.rb`
#### [MODIFY] [init.rb](file:///c:/Users/chris/Downloads/redmine_wysiwyg_editor-0.34.0/init.rb)
- Ensure the new `hooks.rb` file is explicitly required when the plugin initializes.

## Open Questions

> [!IMPORTANT]
> Because Redmine does not strictly track "Wiki Page to Issue" relations in a dedicated database table, this feature will rely on a **text-search (LIKE query)** across all issue descriptions and comments. 
> 
> 1. Do you have a very large database with millions of issues? Text-searching can sometimes be slow on extremely large Redmine instances.
> 2. Do you want this list to appear for *everyone*, or should we restrict it to a specific permission? (By default, I will show it to anyone who has permission to view the wiki).

## Verification Plan

### Manual Verification
1. I will write the code and inject the hook.
2. You can navigate to a Wiki page that you know is mentioned by an Issue.
3. You will verify that a "Related Issues" section appears at the bottom of the page showing the correct issue.
