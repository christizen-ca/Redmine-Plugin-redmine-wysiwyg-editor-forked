# Add Toggle Button for Related Issues

We will add a toggle button to the TinyMCE editor toolbar to control whether the "Related Issues" section is displayed at the bottom of the wiki page. 

## Open Questions

None. This plan handles both the visual editor UI and the backend logic.

## Proposed Changes

We will introduce a special macro `{{related_issues}}`. The presence of this macro in the document will trigger the display of the Related Issues block.

### WYSIWYG Editor JavaScript

#### [MODIFY] `assets/javascripts/redmine_wysiwyg_editor.js`
- Register a new TinyMCE button (`related_issues`) with a toggle state.
- Set up an event listener on `NodeChange` so the button appears "active" if the document contains the `related_issues` marker.
- Add the `related_issues` button to the `toolbar` definition so it appears next to the `attachment` button.
- Add a Turndown rule to ensure the marker is cleanly saved as `{{related_issues}}` in the markdown.

### Redmine Plugin Initialization

#### [MODIFY] `init.rb`
- Register a Redmine macro `{{related_issues}}`. 
- When rendered, this macro will simply output a hidden HTML marker `<div class="wiki-related-issues-marker" style="display:none;" data-macro="related_issues"></div>`.
- This ensures that:
  1. The macro is visually hidden on the actual Wiki page.
  2. The TinyMCE editor can detect the marker to keep the toolbar button state accurate.

### View Hook

#### [MODIFY] `app/views/redmine_wysiwyg_editor/_wiki_issues.html.erb`
- Add a guard clause at the very beginning of the partial:
  `<% return unless @page.content.text.include?('{{related_issues}}') %>`
- The Related Issues script and HTML will ONLY be injected if the toggle was activated by the user in the editor.

## Verification Plan

### Manual Verification
- Open a wiki page and edit it using the visual editor.
- Verify the new icon appears in the toolbar.
- Click the icon to toggle it ON, save the page, and verify the Related Issues appear at the bottom.
- Edit the page again, click the icon to toggle it OFF, save the page, and verify the Related Issues are hidden.
- Verify that the toggle button correctly lights up when editing a page that has the related issues enabled.
